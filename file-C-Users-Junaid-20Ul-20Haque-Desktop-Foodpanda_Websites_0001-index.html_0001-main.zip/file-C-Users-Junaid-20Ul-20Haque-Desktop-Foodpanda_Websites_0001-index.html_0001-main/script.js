document.addEventListener('DOMContentLoaded', () => {
    // Interactive Rainbow Animation on Navbar Hover
    const navbar = document.querySelector('.navbar');
    navbar.addEventListener('mouseover', () => {
        navbar.style.filter = 'brightness(1.2)';
    });
    navbar.addEventListener('mouseout', () => {
        navbar.style.filter = 'brightness(1)';
    });

    // Button Click Alert
    const rainbowButton = document.querySelector('.rainbow-button');
    rainbowButton.addEventListener('click', () => {
        alert('Searching for food!');
    });

    // Footer Interaction
    const footer = document.querySelector('footer');
    footer.addEventListener('mouseover', () => {
        footer.style.boxShadow = '0px 0px 20px rgba(255, 255, 255, 0.8)';
    });
    footer.addEventListener('mouseout', () => {
        footer.style.boxShadow = 'none';
    });
});